<!-- Footer -->
<div class="row">
  <div class="col-md-12" style="display: none;">
    <p align="right"><b>SIS-ADMINISTRASI &copy; 2022</b></p>
  </div>
</div>
<!-- /footer -->
<!-- /content area -->
</div>
<!-- /main content -->
</div>
<!-- /page content -->
</div>
<!-- /page container -->
</body>

</html>