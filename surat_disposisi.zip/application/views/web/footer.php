<!-- Footer -->
<div class="footer text-muted text-center">
	<a href="" class="text-danger"><b>SIS Administrasi</b></a> &copy; 2022
</div>
<!-- /footer -->
</div>
<!-- /content area -->
</div>
<!-- /main content -->
</div>
<!-- /page content -->
</div>
<!-- /page container -->
</body>

</html>